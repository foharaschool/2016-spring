/**
 *  This is the test drive class for LabTwoOneA
 *
 *@author    fohara
 */
public class LabTwoOneATestDrive {
 
    /**
     *  The main program for the LabTwoOneA class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
         LabTwoOneA mathCall = new LabTwoOneA();
         
         mathCall.productMethod();
         
         mathCall.quotientMethod();
		
    }
 
}