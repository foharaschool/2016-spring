// Testdrive class for lab six
public class LabSixTestDrive {
    // Main method for the LabSix program
    public static void main(String[] args) {
        // Instantiate LabSix object
        LabSix mathAintPie = new LabSix();
        
        // Call run method
        mathAintPie.run();
    }
}