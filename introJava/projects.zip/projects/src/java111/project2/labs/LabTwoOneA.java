/**
 *  The LabTwoOneA class which we will use to make math methods
 *
 *@author    fohara
 */
public class LabTwoOneA {
 
	int number5 = 5;
	long number78 = 78;
	double twoand7 = 2.7;
 
    /**
     *  This method calculates the product of multiplying all the instance variables together
     */
	 void productMethod() {
		 System.out.println(number5 * number78 * twoand7);
	 }
	 
	 void quotientMethod() {
		 System.out.println(number78 / number5);
	 }
}