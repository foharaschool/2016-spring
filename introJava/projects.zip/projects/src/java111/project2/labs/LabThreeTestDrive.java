public class LabThreeTestDrive {
    
    public static void main(String[] args) {
        
        LabThree first = new LabThree();
        
        first.sayHello(" like a boss");
        first.sayHelloAgain("Fred", 5);
    }
}