// Test drive class for Student.java
public class StudentTestDrive {
    // Main method for Student program
    public static void main(String[] args) {
        // Instantiate new ProcessStudents object
        ProcessStudents forgottenRealms = new ProcessStudents();
        // Call runStudentProcessing method
        forgottenRealms.runStudentProcessing();
    }
}