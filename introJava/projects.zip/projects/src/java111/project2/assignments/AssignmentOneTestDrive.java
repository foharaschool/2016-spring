/**
 *  The AssignmentOneTestDrive testdrive class  
 *
 *@author    fohara
 */
 public class AssignmentOneTestDrive {
     
     /**
     *  The main program for the AssignmentOne class
     *
     *@param  args  The command line arguments
     */
     public static void main(String[] args) {
         AssignmentOne adder = new AssignmentOne();
         
         adder.runLoop();
     }
 }