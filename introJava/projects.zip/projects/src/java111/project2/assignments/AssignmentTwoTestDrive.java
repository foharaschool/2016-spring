// Test drive class for AssignmentTwo
public class AssignmentTwoTestDrive {
    // Main method for AssignmentTwo program
    public static void main(String[] args) {
        // instantiate AssignmentTwo object
        AssignmentTwo fruitBowlCount = new AssignmentTwo();
        
        // Call run method
        fruitBowlCount.run();
    }
}