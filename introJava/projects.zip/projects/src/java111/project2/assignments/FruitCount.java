// class for counting fruit
public class FruitCount {
    // Private Inst vars
    private String fruit = "fruit";
    private int tallyFruit = 56;
    
    // Accessor methods
    public String getFruit() {
        return fruit;
    }
    
    public void setFruit(String fruit) {
        this.fruit = fruit;
    }
    
    public int getTally() {
        return tallyFruit;
    }
    
    public void setTally(int tallyFruit) {
        this.tallyFruit = tallyFruit;
    }
}