// Class for running the invoice program
public class InvoiceTestDrive {
    // Main method for program
    public static void main(String[] args) {
        // Instantiate invoice process and run
        ProcessInvoice fourTop = new ProcessInvoice();
        fourTop.runProcess();
    }
}