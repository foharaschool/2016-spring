public class MyName {
	public static void main(String[] args) {
		System.out.println("My Name is Fred O'Hara");
        System.out.println("My email address is fohara@madisoncollege.edu");
        
	}
}