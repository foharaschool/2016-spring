public class Contacts {
    String firstName;
    String lastName;
    String address;
    String phone;
    String email;
    
    void display() {
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("email: " + email);
    }
}