public class MyNameLoopTestDrive {
    public static void main(String[] args) {
        MyNameLoop fred = new MyNameLoop();
        fred.nameLoop();
    }
}