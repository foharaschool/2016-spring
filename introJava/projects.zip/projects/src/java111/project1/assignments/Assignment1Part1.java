/**
 * This is a class for
 *
 * @author  fohara
 */
public class Assignment1Part1 {
    
    /**
     * The main program for the Assigment1Part1 class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        
        int counter = 0;
        
        while(counter < 5) {
            System.out.println(counter);
            counter++;
        }
    }
}