public class Cat {
    public void meow() {
        System.out.println("Meow.");
    }
}