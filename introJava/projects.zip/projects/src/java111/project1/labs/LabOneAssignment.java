/**
 * This is the first class in the first lab of the first semester of Java!
 * 
 * @author fohara
 * 
 */
 public class LabOneAssignment
 {
     
    /**
    * This is the main method for this class
    *
    * @param args
    */
    public static void main (String[] args)
    {
        int number = 25;
        String name = "Fred";
        System.out.println(number);
        System.out.println(name);
    }
 }