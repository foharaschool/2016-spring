/**
 * This is the main method for this class
 * 
 * @param args
 */
public class LabTwoLooping {
    public static void main(String[] args) {
        //Your code goes in here
        int counter = 0;
        
        while(counter < 10) {
            counter++;
            System.out.println(counter + " " + (counter * counter));
        }
    }
}