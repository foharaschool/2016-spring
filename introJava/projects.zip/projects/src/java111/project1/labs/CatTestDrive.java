/**
 *  Lab 4 Getting into Objects
 *
 *@author    fohara
 */
 public class CatTestDrive {
     /**
     *  The main program for the Cat class.
     *
     *@param  args  The command line arguments
     */
     public static void main(String[] args) {
         
         Cat cat1 = new Cat();
         cat1.meow();
         
         Cat cat2 = new Cat();
         cat2.meow();
     }
 }