/**
 *  The [] class which 
 *
 *@author    fohara
 */
 
 // Main method javadoc
    /**
     *  The main program for the [] class
     *
     *@param  args  The command line arguments
     */