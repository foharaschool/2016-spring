// Class to hold the one variable I need to run my test
public class RandomNum {
    int randomInt = 0;
}