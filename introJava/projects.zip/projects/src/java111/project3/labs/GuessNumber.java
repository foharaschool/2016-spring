// Create the one variable I need from this stinking class
public class GuessNumber {
    int userNum = 0;
}