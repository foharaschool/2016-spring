// This is the testdrive for project 3
public class Project3TestDrive {
    // Main method for Project 3
    public static void main(String[] args) {
        // Instantiate ClientList object and call run
        ClientList monona = new ClientList();
        monona.run();
    }
}