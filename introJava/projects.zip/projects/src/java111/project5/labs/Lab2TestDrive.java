package java111.project5.labs;

/**
 *  The purpose of this class is to run the demonstation of inherited constructors
 *
 *@author    fohara
 */
public class Lab2TestDrive {
    /**
     *  The main program for the Lab2TestDrive class.
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        ConstructorClass parent = new ConstructorClass();
        ConstructorClass child = new ConstructorSubClass();
    }
}