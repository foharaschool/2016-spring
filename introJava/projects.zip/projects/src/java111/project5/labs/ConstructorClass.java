package java111.project5.labs;

/**
 *  The purpose of this class is to demonstrate calling of a constructor
 *
 *@author    fohara
 */
public class ConstructorClass {
    
    /**
     *  Constructor for the ConstructorClass object
     *
    */ 
    public ConstructorClass() {
        System.out.println("I am the ConstructorClass");
    }
}