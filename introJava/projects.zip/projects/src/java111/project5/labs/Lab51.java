package java111.project5.labs;
 
import java.util.*;
 
/**
 *  Lab 5-1
 *
 *@author    eknapp
 */
public class Lab51 extends java.lang.Object {
 
    /**
     *  Main processing method for the Lab51 object
     */
    public void run() {
 
        System.out.println("[java111.project5.labs.Lab51 > run( )]"
                 + (new Date()).toLocaleString());
 
    }
 
}