package java111.project5.labs;

public class ConstructorSubClass extends ConstructorClass{
    
    public ConstructorSubClass() {
        System.out.println("I am the ConstructorSubClass");
    }
}