package java111.project5.labs;
 
/**
 *  Our first packaged application
 *
 *@author    eknapp
 */
public class PackageExercise {
 
    /**
     *  The main program for the PackageExercise class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello from a packaged app!");
    }
 
}