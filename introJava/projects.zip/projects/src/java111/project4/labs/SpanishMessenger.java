public class SpanishMessenger extends Messenger {
    // Overriding message
    public void message() {
        System.out.println("I am a Spanish messenger.  Ole!");
    }
}