public class FruitSlicer {
    
    public void slice(Fruit aFruit) {
        
        System.out.print("I have sliced a ");
        aFruit.displayClassName();
    }
}