public abstract class Animal {
    public void displayName() {
        System.out.println("I am an Animal");
    }
}