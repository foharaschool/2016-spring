public class Lab5Testdrive {
    public static void main(String[] args) {
        Animal corgie = new Doge();
        
        corgie.displayName();
    }
}