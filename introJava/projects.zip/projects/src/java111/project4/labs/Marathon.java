public class Marathon implements Event {
    public void display() {
        System.out.println("I'm a Marathon. Boom.");
    }
}