public class Messenger {
    public void message() {
        System.out.println("I am a messenger");
    }
}