public class FruityTestDrive {
    public static void main(String[] args) {
        Fruit aFruit = new Fruit();
        Fruit aPlum = new Plum();
        Fruit aPrune = new Prune();
        
        aFruit.displayClassName();
        aPlum.displayClassName();
        aPrune.displayClassName();
    }
}