public class Meeting implements Event {
    public void display() {
        System.out.println("I'm a meeting!");
    }
}