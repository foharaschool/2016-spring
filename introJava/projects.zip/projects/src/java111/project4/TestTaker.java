public interface TestTaker {
    
    public void takeTest();
    
    public String getTestResults();
}