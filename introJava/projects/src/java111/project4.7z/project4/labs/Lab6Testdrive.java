public class Lab6Testdrive {
    public static void main(String[] args) {
        Bird fawks = new Phoenix();
        
        fawks.displayName();
    }
}