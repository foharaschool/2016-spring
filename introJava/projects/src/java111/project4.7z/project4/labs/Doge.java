public class Doge extends Animal {
    public void displayName() {
        System.out.println("I am a Doge.");
    }
}