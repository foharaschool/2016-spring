public class Prune extends Plum {
    public void displayClassName() {
        System.out.println("Prune");
    }
}