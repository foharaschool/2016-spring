public class Fruit {
    public void displayClassName() {
        System.out.println("Fruit");
    }
}