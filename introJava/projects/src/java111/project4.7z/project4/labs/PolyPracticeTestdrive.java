import java.util.*;
public class PolyPracticeTestdrive {
    public static void main(String[] args) {
        FruitArray basket = new FruitArray();
        
        
        basket.fruitBasket.add(new Fruit());
        basket.fruitBasket.add(new Plum());
        basket.fruitBasket.add(new Prune());
        basket.displayArray();
    }
}