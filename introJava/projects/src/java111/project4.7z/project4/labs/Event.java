public interface Event {
    public void display();
}