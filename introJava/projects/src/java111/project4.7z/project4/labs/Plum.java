public class Plum extends Fruit {
    public void displayClassName() {
        System.out.println("Plum");
    }
}