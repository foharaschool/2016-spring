public class Phoenix extends Bird {
    public void displayName() {
        System.out.println("I am a Phoenix");
    }
}